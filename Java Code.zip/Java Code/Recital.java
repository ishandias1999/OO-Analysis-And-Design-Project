import java.util.Vector;

public class Recital {
	private int _studentId;
	public Vector<Student> _takes_part_in = new Vector<Student>();
}