public class Search_Best_Student_Controller {
	public Student _unnamed_Student_;

	public void findBestStudentForGradeLevel(Object aGradeLevel) {
		throw new UnsupportedOperationException();
	}
}