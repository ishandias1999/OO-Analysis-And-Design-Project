import java.util.Vector;

public class HopeMusicAcademy {
	private String _phoneNum;
	private String _email;
	public Vector<School> _unnamed_School_ = new Vector<School>();
	public Head_Office _unnamed_Head_Office_;
}