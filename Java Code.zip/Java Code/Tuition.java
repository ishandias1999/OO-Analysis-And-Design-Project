public class Tuition {
	private int _termNum;
	private int _tutorId;
	private String _roomNum;
	public Tutor _associated;
	public SingingTuition _may_be;
	public Term _provided_over;
}