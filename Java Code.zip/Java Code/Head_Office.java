import java.util.Vector;

public class Head_Office {
	private String _location = Limerick;
	public HopeMusicAcademy _unnamed_HopeMusicAcademy_;
	public Vector<Suppliers> _approves = new Vector<Suppliers>();
}