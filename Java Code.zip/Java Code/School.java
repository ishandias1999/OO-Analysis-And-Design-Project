import java.util.Vector;

public class School {
	private String _name;
	private int _numStudents;
	private String _location;
	private String _phoneNum;
	public HopeMusicAcademy _unnamed_HopeMusicAcademy_;
	public Orchestra _unnamed_Orchestra_;
	public Orchestra_Controller _unnamed_Orchestra_Controller_;
	public Vector<Purchase> _unnamed_Purchase_ = new Vector<Purchase>();

	public void getSchool(Object aSchoolnName) {
		throw new UnsupportedOperationException();
	}
}