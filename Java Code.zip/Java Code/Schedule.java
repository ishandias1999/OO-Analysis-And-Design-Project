public class Schedule {
	private int _assessmentNum;
	private String _location;
	private String _time;
	public Student _unnamed_Student_;
	public Assessment _unnamed_Assessment_;

	public void setUnnamed_Student_(Student aUnnamed_Student_) {
		this._unnamed_Student_ = aUnnamed_Student_;
	}

	public Student getUnnamed_Student_() {
		return this._unnamed_Student_;
	}

	public void setUnnamed_Assessment_(Assessment aUnnamed_Assessment_) {
		this._unnamed_Assessment_ = aUnnamed_Assessment_;
	}

	public Assessment getUnnamed_Assessment_() {
		return this._unnamed_Assessment_;
	}
}