public class ContactInformation extends Information {
	private String _address;
	private String _phoneNum;
}