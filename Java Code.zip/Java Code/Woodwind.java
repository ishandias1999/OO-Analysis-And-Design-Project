public class Woodwind extends Instrument {
}