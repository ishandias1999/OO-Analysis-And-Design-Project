public class Term {
	private int _termNum;
	private String _startDate;
	private String _endDate;
	public Tuition _provided_over;
}