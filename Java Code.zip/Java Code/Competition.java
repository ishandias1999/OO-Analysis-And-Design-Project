import java.util.Vector;

public class Competition {
	private String _reward;
	private int _studentId;
	private int _year;
	public Competition_Controller _unnamed_Competition_Controller_;
	public Vector<Student> _unnamed_Student_ = new Vector<Student>();

	public void getCompetition(Object aYear) {
		throw new UnsupportedOperationException();
	}
}