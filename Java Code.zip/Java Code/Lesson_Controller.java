public class Lesson_Controller {
	public Student _unnamed_Student_;
	public InstrumentTuition _unnamed_InstrumentTuition_;

	public void checkGrade(Object aStudentId) {
		throw new UnsupportedOperationException();
	}

	public void enrolStudent(Object aStudentId, Object aName, Object aGradeLevel, Object aInstrumentId) {
		throw new UnsupportedOperationException();
	}

	public void addToWaitingList(Object aStudentId, Object aStudentName) {
		throw new UnsupportedOperationException();
	}
}