import java.util.Vector;

public class Orchestra {
	private String _schoolName;
	private Student _studentList;
	public Vector<Student> _contains = new Vector<Student>();
	public School _has_an;
	public Vector<Concert> _performs = new Vector<Concert>();

	public void getOrchestra() {
		throw new UnsupportedOperationException();
	}
}