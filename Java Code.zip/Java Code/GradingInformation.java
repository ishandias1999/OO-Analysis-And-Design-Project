public class GradingInformation extends Information {
	private int _assessmentNum;
	private float _grade;
	private int _studentId;
	public Assessment _consists;

	public void getGrade() {
		throw new UnsupportedOperationException();
	}
}