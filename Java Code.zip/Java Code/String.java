public class String extends Instrument {
}