import java.util.Vector;

public class Assessment {
	private int _assessmentNum;
	public Vector<Schedule> _unnamed_Schedule_ = new Vector<Schedule>();
	public Vector<Tutor> _grade = new Vector<Tutor>();
	public Vector<GradingInformation> _consists = new Vector<GradingInformation>();
}