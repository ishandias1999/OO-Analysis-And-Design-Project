public class PaymentInformation extends Information {
	private String _paymentMethod;
	private float _amount;
	private float _discountRate;
	private String _date;
}