public class EntryAssessment extends Assessment {
	public Exam_Controller _unnamed_Exam_Controller_;

	public void addStudentToExam(Object aStudentName) {
		throw new UnsupportedOperationException();
	}
}