public class Information {
	private String _name;
	private int _gradeLevel;
	private int _numWins;
	public Student _has;

	public void getGradeLevel() {
		throw new UnsupportedOperationException();
	}
}