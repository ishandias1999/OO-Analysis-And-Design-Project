import java.util.Vector;

public class SingingTuition {
	private int _numStudents;
	public Vector<Student> _unnamed_Student_ = new Vector<Student>();
	public Tuition _unnamed_Tuition_;
}