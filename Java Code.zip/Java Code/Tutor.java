import java.util.Vector;

public class Tutor {
	private int _tutorId;
	private String _name;
	public Search_Student_For_Tutor_Controller _unnamed_Search_Student_For_Tutor_Controller_;
	public Vector<Tuition> _associated = new Vector<Tuition>();
	public Vector<Assessment> _grade = new Vector<Assessment>();

	public void verifyTutor(Object aTutorId) {
		throw new UnsupportedOperationException();
	}

	public void getTutor() {
		throw new UnsupportedOperationException();
	}
}