import java.util.Vector;

public class Instrument {
	private String _name;
	private int _id;
	public Vector<Suppliers> _sell = new Vector<Suppliers>();
	public Loan _unnamed_Loan_;
	public Loan_Controller _unnamed_Loan_Controller_;
	public Vector<InstrumentTuition> _taught_in = new Vector<InstrumentTuition>();

	public void verifyInstrument(Object aInstrumentId) {
		throw new UnsupportedOperationException();
	}

	public void getInstrument() {
		throw new UnsupportedOperationException();
	}

	public void getInstrument(Object aInstrumentId) {
		throw new UnsupportedOperationException();
	}
}