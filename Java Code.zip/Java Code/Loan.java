public class Loan {
	private int _loanNum;
	private int _studentId;
	private int _instrumentId;
	private String _dateFrom;
	private String _dateTo;
	public Loan_Controller _unnamed_Loan_Controller_;
	public Student _unnamed_Student_;
	public Instrument _unnamed_Instrument_;

	public void setUnnamed_Student_(Student aUnnamed_Student_) {
		this._unnamed_Student_ = aUnnamed_Student_;
	}

	public Student getUnnamed_Student_() {
		return this._unnamed_Student_;
	}

	public void setUnnamed_Instrument_(Instrument aUnnamed_Instrument_) {
		this._unnamed_Instrument_ = aUnnamed_Instrument_;
	}

	public Instrument getUnnamed_Instrument_() {
		return this._unnamed_Instrument_;
	}
}