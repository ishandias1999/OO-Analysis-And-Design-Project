public class InstrumentTuition {
	private String _instrumentName;
	public Instrument _taught_in;
	public Tuition _unnamed_Tuition_;
	public Lesson_Controller _unnamed_Lesson_Controller_;
	public Student _unnamed_Student_;

	public void addToLesson(Object aStudentId, Object aName, Object aGradeLevel) {
		throw new UnsupportedOperationException();
	}

	public void addInstrument(Object aInstrumentId) {
		throw new UnsupportedOperationException();
	}
}