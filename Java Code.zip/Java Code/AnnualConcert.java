public class AnnualConcert extends Concert {
}