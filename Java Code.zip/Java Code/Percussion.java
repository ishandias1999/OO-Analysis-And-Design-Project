public class Percussion extends Instrument {
}