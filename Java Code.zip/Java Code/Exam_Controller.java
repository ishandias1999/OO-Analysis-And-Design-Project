public class Exam_Controller {
	public EntryAssessment _unnamed_EntryAssessment_;
	public EndTermAssessment _unnamed_EndTermAssessment_;

	public void registerStudentExam() {
		throw new UnsupportedOperationException();
	}

	public void registerStudentEndExam(Object aStudentId, Object aGradeLevel) {
		throw new UnsupportedOperationException();
	}

	public void registerStudentEntryExam(Object aStudentName) {
		throw new UnsupportedOperationException();
	}
}