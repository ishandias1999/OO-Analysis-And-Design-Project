public class Purchase {
	private String _supplier;
	private String _instrumentName;
	public School _unnamed_School_;
	public Suppliers _unnamed_Suppliers_;

	public void setUnnamed_School_(School aUnnamed_School_) {
		this._unnamed_School_ = aUnnamed_School_;
	}

	public School getUnnamed_School_() {
		return this._unnamed_School_;
	}

	public void setUnnamed_Suppliers_(Suppliers aUnnamed_Suppliers_) {
		this._unnamed_Suppliers_ = aUnnamed_Suppliers_;
	}

	public Suppliers getUnnamed_Suppliers_() {
		return this._unnamed_Suppliers_;
	}
}