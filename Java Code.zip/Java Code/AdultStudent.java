public class AdultStudent extends Student {
}