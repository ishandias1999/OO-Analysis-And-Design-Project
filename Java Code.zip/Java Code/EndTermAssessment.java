public class EndTermAssessment extends Assessment {
	private int _gradeLevel;
	public Exam_Controller _unnamed_Exam_Controller_;

	public void addStudentToExam(Object aStudentId, Object aGradeLevel) {
		throw new UnsupportedOperationException();
	}
}