import java.util.Vector;

public class Student {
	private int _id;
	private boolean _status;
	private double _attendanceRate;
	public InstrumentTuition _attends;
	public Information _has;
	public Recital _takes_part_in;
	public Competition _participates;
	public Lesson_Controller _unnamed_Lesson_Controller_;
	public Loan_Controller _unnamed_Loan_Controller_;
	public Search_Best_Student_Controller _unnamed_Search_Best_Student_Controller_;
	public Search_Student_For_Tutor_Controller _unnamed_Search_Student_For_Tutor_Controller_;
	public Vector<Schedule> _unnamed_Schedule_ = new Vector<Schedule>();
	public Orchestra _contains;
	public Loan _unnamed_Loan_;
	public Search_Grade_Student_Controller _unnamed_Search_Grade_Student_Controller_;

	public void verifyStudent(Object aStudentId) {
		throw new UnsupportedOperationException();
	}

	public void getStudent() {
		throw new UnsupportedOperationException();
	}

	public void getStudent(Object aStudentId) {
		throw new UnsupportedOperationException();
	}
}