public class Competition_Controller {
	public Competition _unnamed_Competition_;

	public void getWinner() {
		throw new UnsupportedOperationException();
	}
}