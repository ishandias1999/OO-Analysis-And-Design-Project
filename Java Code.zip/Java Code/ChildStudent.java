public class ChildStudent extends Student {
}