public class Loan_Controller {
	public Student _unnamed_Student_;
	public Instrument _unnamed_Instrument_;
	public Loan _unnamed_Loan_;

	public void loanInstrument(Object aStudentId, Object aInstrumentId, Object aDateTo, Object aDateFrom) {
		throw new UnsupportedOperationException();
	}
}