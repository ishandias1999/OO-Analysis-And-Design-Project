public class Concert {
	private String _date;
	private String _time;
	private String _location;
	public Orchestra _performs;
}