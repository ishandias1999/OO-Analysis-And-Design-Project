import java.util.Vector;

public class Suppliers {
	private String _name;
	private String _address;
	private String _phoneNum;
	public Vector<Purchase> _unnamed_Purchase_ = new Vector<Purchase>();
	public Head_Office _approves;
	public Vector<Instrument> _unnamed_Instrument_ = new Vector<Instrument>();
}