public class TeenStudent extends Student {
}