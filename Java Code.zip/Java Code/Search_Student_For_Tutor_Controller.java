public class Search_Student_For_Tutor_Controller {
	public Student _unnamed_Student_;
	public Tutor _unnamed_Tutor_;

	public void getAllStudentsForTutor(Object aTutorId) {
		throw new UnsupportedOperationException();
	}
}